sleep 400 &
sleep 559&
jobhs
jobs
sleep 2345
bg %3
jobs
kill sleep
pkill sleep
top -l -u amiralsayed
top -lu amiralsayed
top
top -u amiralsayed
clear
ps -u amiralsayed
ps | grep -v amiralsayed
ps
ps aux | grep -v amiralsayed
ps au | grep -v amiralsayed
pgrep -u amiralsayed
pgrep -lu amiralsayed
clear
ps aux | grep -v "amiralsayed"
vim lab4_lecture_commands.sh 
ps -a
ps a
clear
 ps a
ps ax
ps au
ps aux
ps aux | grep -v amiralsayed
ps aux | grep -v amiralsayed | wc -l
ps aux | grep  amiralsayed | wc -l
ps
clear
pgrep
pgrep sleep
kill 10933
ps
ps -e
ps --help
clear
ps -e | grep -v amiralsayed
ps -le | grep -v amiralsayed
ps -le | grep  amiralsayed
ps aux
clear
ps -fu amiralsayed
clear
ps -fu amiralsayed
ps -f | grep -v amiralsayed
pgrep -u amiralsayed
pgrep -lu amiralsayed
clear
compgen > /tmp/commands.list;
cat /tmp/commands.list 
compgen
compgen -c
compgen - > /tmp/commands.list;
compgen -c > /tmp/commands.list;
cat /tmp/commands.list 
compgen -c | wc -l
cat /etc/passwd | grep $g
cat /etc/passwd | grep ^g
find / -name .bash_profile 2>/dev/null;
find / -name .bash_profile 
cler
clear
who | wc -l
head -n 10 /etc/passwd | tail -n 3;
ls
cat one 
cat two
cat one | cat two
ls | rm
ls /etc/passwd
ls /etc/passwd | wc -l
sleep 100
jobs
bg %2
jobs
cl;ear
clear
sleep 2342
sleep 333&
sleep 3343&
sleep 343&
jobs
fg %2
bg %2
jobs
pkill sleep
top -u amiralsayed
ps -fu amiralasayed
ps -fu amiralayed
ps -fu amiralsayed
ps aux | grep -v amiralayed
ps aux | grep -v amiralayed |wc -l
ps aux | grep  amiralayed |wc -l
pgrep -u amiralsayed
pgrep -lu amiralsayed
clear
ls
exit
jobs
pgrep sleep
pkill [200~head -n 10 /etc/passwd | tail -n 3;
pkill 11858
11855
exit
mv lab4.sh lab4_lecture_commands.sh
vim lab4_solution.sh
ls
vim lab4_solution.sh
ls
vim lab4.sh
clear
vim lab4.sh 
exit
ls
clear
ls
cd Desktop/
ls
cd iti_open_source/
ls
cd redHat/
ls
vim lab2.sh 
cut -d : -f 1, 3 /etc/passwd
cut -d : -f 1,3 /etc/passwd
cut -d : -f 1,3 /etc/passwd | grep ^g
cut -d : -f 1,3,5 /etc/passwd | grep ^g
cut -d : -f 1,5 /etc/passwd | grep ^g
cut -d : -f 1,5 -o gNames /etc/passwd | grep ^g | sort -t : -k 2
cut -d : -f 1,5 /etc/passwd | grep ^g | sort -t : -k 2
cut -d : -f 1,5 /etc/passwd | grep ^g | sort -t : -k 1
cut -d : -f 1,5 /etc/passwd | grep ^g | sort -t : -k 2cut -d : -f 1,5  /etc/passwd | grep ^g | sort -t : -k 2 >> gnames
cut -d : -f 1,5  /etc/passwd | grep ^g | sort -t : -k 2 >> gnames
ls
cat gnames 
clear
ls
ls -R
ls --help
clear
ls -R /
clear
ls -R /
jobs
ls -R &
ls -R / &
bg ls -R /
bg --help
ls -R / &
cut -d : -f 1 /etc/passwd
cut -d :: -f 1 /etc/passwd
cut -d p -f 1 /etc/passwd
cut -d : -f 1 /etc/passwd
sort -t : -k 3 -n -o botato /etc/passwd
cat botato 
rm botato 
sort -t : -k 3 -n -o botato /etc/passwd | cat -d : -f 1
sort -t : -k 3 -n  /etc/passwd | cat -d : -f 1
sort -t : -k 3 -n  /etc/passwd | cut -d : -f 1
sort -t : -k 3 -n  /etc/passwd | cut -d : -f 1 >> botato
ls
cat botato 
rm botato 
ls
clear
df
du .
du . -h
du . -hs
du . -hs 2> /dev/null 
locate --help
find password
locat password
locate passwd
locate passwd |wd -l
locate passwd |wc -l
find /etc botato
find /etc -name botato
find /etc -name botato 2> /dev/null 
find /etc -name passwd 2> /dev/null 
find /etc -user 1000 2> /dev/null 
find /etc -perm 644 2> /dev/null 
find /etc -user 1000 2> /dev/null clear
clear
arch --help
ls
cd Desktop/
ls
cd iti_open_source/
ls
cd redHat/
ls
cd lab5/
mkdir d1 d2
touch f1 f2
man man >> f1
man man | echo f1
cat f1
clear
cp f1 f2
cp f1 d1/
cp f1 d2/
tar -jcf botato.tar f1 f2 d1 d2
ls
ls -lh botato.tar 
ls -lh
tar -cf botato.tar f1 f2 d1 d2
ls -lh
ls
clear
vim lectureCommands.sh 
clear
ls -R / 2>errors.txt | sort > files.txt &
jobs
clear
ls
cat files.txt l
exit
vim lectureCommands.sh 
jobs
bg 1
jobs
clear
ls -R / > files.txt 2>errors.txt &
jobs
ls
cat files.txt 
clear
cat errors.txt 
clear
ls
ls -R / | sort  > files.txt 2>errors.txt &
ls
clear
ls
rm files.txt errors.txt 
man man
man man >> bigFile.txt
ls
ls -i
ls -lh
cp files.txt bigFile.txt 
ls -l
ls -lh
clear
gzip bigFile.txt 
ls
ls -lh
gunzip bigFile.txt.gz 
ls -lh
compress bigFile.txt # depricated, can not run it on my machien
gzip bigFile.txt # compresses files only >> reduced from 11M to 2M
ls -lh
gunzip bigFile.txt.gz # return it to the original size
ls -lh
zip bigFile.txt # compresses files and directories together
ls -lh
unzIp bigFile.txt.zip
ls -lh
clear
zip bigFile.txt 
zip --help
clear
zip bootato.zip bigFile.txt 
zip botato.zip  bigFile.txt     # compresses files and directories together
ls -lh
rm bootato.zip 
ls
ls -lh
ls -lh bigFile.txt botato.zip 
unzip botato.zip 
ls
ls -lh
rm botato
ls
rm botato.zip 
ls
gzip bigFile.txt 
zcat bigFile.txt.gz 
clear
gunzip bigFile.txt.gz 
zip botato.zip bigFile.txt 
ls
unzip -l botato.zip 
tar -cf etcBackup.tar /etc/
tar -cf etcBackup.tar /etc
tar -cf etcBackup.tar etc
tar -cf etcBackup.tar etc/
tar -cf etcBackup.tar /etc
tar -cf etcBackup.tar /etc 2> /dev/null 
ls
rm botato.zip 
tar -tf etcBackup.tar 
clear
find --help
find --help | grep "time"
find / -mtime +2
find / -mtime -2
find /home/ -mtime -2
find /home/ -mtime -2 2> /dev/null 
find /home/ -mtime -2 2> /dev/null | wc -l
find / -type f -mtime -2 2> /dev/null | wc -l
find /home -type f -mtime -2 2> /dev/null | wc -l
find /home  -mtime -2 2> /dev/null | wc -l
find /home/  -mtime -2 2> /dev/null | wc -l
find /etc/ -user root
find /etc/ -user root 2> /dev/null
find /etc/ -user root 2> /dev/null | wc -l
find /etc/ -user root | wc -l
ls ~
find /etc/ -user root 2> /dev/null
clear
find ~ -type d
find ~ -type d 
find ~ -type d | wc -l
find / -name ".profile"
find / -name ".profile" 2> /dev/null
find / -type f -name ".profile" 2> /dev/null
touch .profile
find / -type f -name ".profile" 2> /dev/null
file /etc/passwd
clear
find /etc/passwd
find /dev/pts/0
find /etc
find /dev/sda
clear
file /etc/passwd
file /dev/pts/0
file /etc
file /dev/sda
ls -i / /etc/ /etc/hosts
ls -id / /etc/ /etc/hosts
ls -id1 / /etc/ /etc/hosts
cp /etc/passwd ~/passwdCopy
ls ~
diff /etc/passwd ~/passwdCopy 
cmp /etc/passwd ~/passwdCopy 
vim ~/passwdCopy 
cmp /etc/passwd ~/passwdCopy 
diff /etc/passwd ~/passwdCopy 
cat lectureCommands.sh 
clear
ls
vim lab5.sh 
exit
ls
cd Desktop/iti_open_source/
ls
cd redHat/
ls
mkdir lab5
cd lab5
vim lectureCommands.sh
ls
clear
ls
vim lab5.sh
cat lab5.sh 
clear
cut -d : -f 1,5 /etc/passwd | grep ^g
clear
ls
clear
cut -d : -f 1,5 /etc/passwd | grep ^g
cut -d : -f 1,5  /etc/passwd | grep ^g | sort -t : -k 2 >> gnames
ls
cat gnames 
rm gnames 
cut -d : -f 1,5  /etc/passwd | grep ^g | sort -t : -k 2 >> gnames
ls gnames 
cat gnames 
clear
ls -R / 2>errors.txt | sort > files.txt &
ls
cat files.txt 
clear
ls -lh 
clear
gzip bigFile.txt 
ls
ls -lh
zip botato.zip  bigFile.txt
ls
clear
ls
gunzip bigFile.txt.gz 
ls
zip botato.zip  bigFile.txt
ls
ls -lh
cl;ear
clear
unzip botato.zip 
ls -lh
gzip amir 
ls
cat amir.gz 
zcat amir.gz 
cear
clear
tar -cf etcBackup.tar /etc
ls
find ~ -type f -mtime -2 2> /dev/null
clear
find /etc/ -user root 2> /dev/null
find ~ -type d
clear
find / -type f -name ".profile" 2> /dev/null
clear
file /etc/passwd
file /dev/pts/0
file /etc
file /dev/sda
clear
ls -id1 / /etc/ /etc/hosts
ls ~/
rm ~/passwdCopy 
ls
clear
cp /etc/passwd ~/passwdCopy
ls ~/
diff /etc/passwd ~/passwdCopy # nothing happens
cmp /etc/passwd ~/passwdCopy # nothing happens
vim ~/passwdCopy 
cmp /etc/passwd ~/passwdCopy # nothing happens
diff /etc/passwd ~/passwdCopy # nothing happens
sudo ln -s /etc/passwd /boot/passwd_symlink
sudo ln /etc/passwd /boot/passwd_hardlink
clear
ls
rm  /boot/passwd_hardlink
sudo rm  /boot/passwd_hardlink
ls /boot/pass*
sudo rm /boot/passwd_symlink 
ls /boot/pass*
cldear
clear
exit
awk --help
awk -F: 'print $1, $5' /etc/passwd
awk -F: '{print $1, $5}' /etc/passwd
awk -F: '{print $1,"||", $5}' /etc/passwd
awk -F: 'print $0' /etc/passwd
awk -F: 'BEGIN{FS=":"; print "LogName\t\tFullName"}{print $1"\t\t" $5' /etc/passwd
awk -F: 'BEGIN{ print "LogName\t\tFullName" } { print $1"\t\t" $5 }' /etc/passwd
awk 'BEGIN{ print "LogName\t\tFullName"; FS=":" } { print $1"\t\t" $5 }' /etc/passwd
awk 'END{ print "LogName\t\tFullName"; FS=":" } { print $1"\t\t" $5 }' /etc/passwd
awk 'BEGIN{ print "LogName\t\tFullName"; FS=":" } { print $1"\t\t" $5 }' /etc/passwd
vim lec1.sh 
cat lec1.sh 
awk -F: '{
    sum_by_group[$3] += $2
}
END {
    for (group in sum_by_group) {
        print group, sum_by_group[group]
    }
}' /etc/passwd
awk -F: '{
    # Group by $4 (GID), Sum $3 (UID)
    sum_by_group[$4] += $3
}
END {
    for (group in sum_by_group) {
        print group, sum_by_group[group]
    }
}' /etc/passwd
cat /etc/passwd
sed -n '/lb/p' /etc/passwd
sed -n '/ib/p' /etc/passwd
sed -n '/amir/p' /etc/passwd
sed -n '/lp/p' /etc/passwd
sed -n '3dp' /etc/passwd
sed -n '3d' /etc/passwd
sed '3d' /etc/passwd
sed '' /etc/passwd
sed '$d' /etc/passwd
sed '' /etc/passwd
sed '$d' /etc/passwd
sed '$0d' /etc/passwd
clear
cat /etc/passwd || wc -l
cat /etc/passwd >> wc -l
wc -l /etc/passwd
sed '/lp/d' /etc/passwd || wc -l
sed '/lp/d' /etc/passwd | wc -l
sed '%s/lp/mylp/g' /etc/passwd
sed '/%s/lp/mylp/g' /etc/passwd
sed 's/lp/mylp/g' /etc/passwd
awk -F: 'print $5' /etc/passwd
awk -F: '{print $5}' /etc/passwd
awk -F: '{print RN,$1,$5,$7}' /etc/passwd
awk -F: '{print RN,$1,$5,$6}' /etc/passwd
awk -F: '{print RN"=>"$1"<-->"$5"<-->"$6}' /etc/passwd
awk -F: '{print NR"=>"$1"<-->"$5"<-->"$6}' /etc/passwd
awk -F: '{print RN"=>"$1"/t"$5"/t"$6}' /etc/passwd
awk -F: '{print RN"=>"$1"\t"$5"\t"$6}' /etc/passwd
awk -F: '{print $0}' /etc/passwd
awk -F: '{print $3}' /etc/passwd
awk -F: '{if($3 > 500){print $3}' /etc/passwd
awk -F: '{if($3 > 500){print $3}}' /etc/passwd
awk -F: '{if($3 > 500){print $1$3$5}}' /etc/passwd
awk -F: '{if($3 > 500){print $1"\t"$3"\t"$5}}' /etc/passwd
awk -F: '{if($3 > 500){print $1"\tt"$3"\tt"$5}}' /etc/passwd
awk -F: '{if($3 > 500){print $1"\ttt"$3"\ttt"$5}}' /etc/passwd
awk -F: '{if($3== 500){print $1"\t"$3"\t"$5}}' /etc/passwd
awk '{if(NR >4 && NR < 16){print  $0}}' /etc/passwd
awk '{if(NR >4 && NR < 16){print NR $0}}' /etc/passwd
awk '{if(NR >4 && NR < 16){print NR"==>" $0}}' /etc/passwd
awk -F: 'BEGIN{max=0}{max+=$3}END{print "max is "max}' /etc/passwd
awk -F: 'BEGIN{sum=0}{sum+=$3}END{print "sum is "sum}' /etc/passwd
cleawr
clear
awk -F: '$1 == "lp" {$1 = "mylp"} {print}' /etc/passwd
cat /etc/passwd
awk -F: '
{
BEGIN {
        max_uid = 0
}
    if ($3 > max_uid) {
        max_uid = $3;
        max_line = $0;
    }
}
END {
    print max_line
}
' /etc/passwd
awk -F: '
BEGIN {
        max_uid = 0
}
    if ($3 > max_uid) {
        max_uid = $3;
        max_line = $0;
    }
}
END {
    print max_line
}
' /etc/passwd
awk -F: '
BEGIN {
        max_uid = 0
}
{ if ($3 > max_uid) {
        max_uid = $3;
        max_line = $0;
    }
}
END {
    print max_line
}
' /etc/passwd
awk -F: '
{ if ($3 > max_uid) {
        max_uid = $3;
        max_line = $0;
    }
}
END {
    print max_line
}
' /etc/passwd
awk -F: '{if($1 == "lp") {$1 = "mylp"}} {print}' /etc/passwd
clear
echo "User-Group Report"
echo "--------------------------"
# 1. Extract GID ($4) and Username ($1) from /etc/passwd
# 2. Sort by GID to group users together
# 3. Process with awk to print the group name once per group and then list users
awk -F: '
    # Create an array to map GID to Group Name
    BEGIN { while (getline < "/etc/group" > 0) { split($0, a, ":"); gid_to_name[a[3]] = a[1]; } close("/etc/group"); }
    
    # Use $4 (GID) as the key, add $1 (Username) to the list
    { users_by_group[$4] = users_by_group[$4] (users_by_group[$4]==""?"":"\n") $1 }

    # END block: Print the formatted report
    END {
        for (gid in users_by_group) {
            # Print the Group Name (mapped from GID)
            print "\n" gid_to_name[gid] " Name:"
            
            # Print the list of users associated with that GID
            print users_by_group[gid]
        }
    }
' /etc/passwd | sort
awk -F: '
BEGIN { 
    while (getline < "/etc/group" > 0) { 
        split($0, a, ":"); 
        gid_to_name[a[3]] = a[1]; 
    } 
    close("/etc/group"); 
    print "User-Group Report\n--------------------------"; 
}
{ 
    # $4 is the GID in /etc/passwd
    # $1 is the username in /etc/passwd
    users_by_group[$4] = users_by_group[$4] (users_by_group[$4]==""?"":"\n") $1 
}
END {
    for (gid in users_by_group) {
        print ""
        print gid_to_name[gid] " Name:"
        print users_by_group[gid]
    }
}' /etc/passwd
clear
echo "User-Group Report"
echo "--------------------------"
# The main pipeline:
awk -F: '{print $4, $1}' /etc/passwd | sort -k1,1 | awk '
    {
        current_gid = $1;
        username = $2;
        
        # Check if the Group ID has changed from the previous line
        if (current_gid != last_gid) {
            # Print an empty line for spacing
            print ""
            # Print the new Group ID as the header
            print "Group ID:", current_gid
            last_gid = current_gid;
        }
        
        # Print the username
        print username
    }
'
clear
awk -F: '{
    sum_by_group[$4] += $3
}
END {
    for (group in sum_by_group) {
        print group, sum_by_group[group]
    }
}' /etc/passwd
clear
cat /etc/passwd
clear
echo "User-Group Report"
echo "--------------------------"
awk -F: '{print $4, $1}' /etc/passwd | sort | awk '
    {
        current_gid = $1;
        username = $2;
        
        # If GID changes, print the header
        if (current_gid != last_gid) {
            print ""
            print "Group ID:", current_gid
            last_gid = current_gid;
        }
        
        # Print the user
        print username
    }
'
# user group reprot :__:
echo "User-Group Report"
echo "--------------------------"
awk -F: '{print $4, $1}' /etc/passwd | sort | awk '
    {
        current_gid = $1;
        username = $2;
        if (current_gid != last_gid) {
            print ""
            print "Group ID:", current_gid
            last_gid = current_gid;
        }
        print username
    }
'
clear
awk -F: '{if($1 == "lp") {$1 = "mylp"}}' /etc/passwd
awk -F: '{if($1 == "lp") {$1 = "mylp"}}{print $0}' /etc/passwd
echo "User-Group Report"
echo "--------------------------"
awk -F: '{print $4, $1}' /etc/passwd | sort -n | awk '
    {
        current_gid = $1;
        username = $2;
        if (current_gid != last_gid) {
            print ""
            print "Group ID:", current_gid
            last_gid = current_gid;
        }
        print username
    }
'
clear
sed -n '/lp/p' /etc/passwd
sed  '3d' /etc/passwd
sed '%d' /etc/passwd
sed '$d' /etc/passwd
sed '/lp/d' /etc/passwd
clear
sed 's/lp/mylp/g' /etc/passwd
awk -F: '{print $5}' /etc/passwd
cledar
clear
awk -F: '{print RN"=>"$1"\t"$5"\t"$6}' /etc/passwd
awk -F: '{print NR"=>"$1"\t"$5"\t"$6}' /etc/passwd
clear
awk -F: '{if($3 > 500){print $1"\t"$3"\t"$5}}' /etc/passwd
awk -F: '{if($3 == 500){print $1"\t"$3"\t"$5}}' /etc/passwd
awk -F: '{if($3 == 1000){print $1"\t"$3"\t"$5}}' /etc/passwd
awk '{if(NR >4 && NR < 16){print NR"==>" $0}}' /etc/passwd
awk -F: '{if($1 == "lp") {$1 = "mylp"}} {print}' /etc/passwd
cldear
clear
awk -F: '
{ if ($3 > max_uid) {
        max_uid = $3;
        max_line = $0;
    }
}
END {
    print max_line
}
' /etc/passwd
awk -F: '{
    sum_by_group[$4] += $3
}
END {
    for (group in sum_by_group) {
        print group, sum_by_group[group]
    }
}' /etc/passwd
clear
echo "User-Group Report"
echo "--------------------------"
awk -F: '{print $4, $1}' /etc/passwd | sort -n | awk '
    {
        current_gid = $1;
        username = $2;
        if (current_gid != last_gid) {
            print ""
            print "Group ID:", current_gid
            last_gid = current_gid;
        }
        print username
    }
'
elcear
exit
ls
cd 
cd Desktop/iti_open_source/
ls
mkdir bash
cd baa
cd bash/
ls
vim lecture1.sh
chmod +x lecture1.sh 
./lecture1.sh 
ls
rm file*
ls
clear
vim lecture1.sh 
cat lecture1.sh 
cp lecture1.sh lec1.sh 
rm lecture1.sh 
vim lec1.sh 
vim lab1.sh
ls
clear
ls
rm wc 
ls
vim lab1.sh 
ls
vim lab1.
vim  lab1.sh 
clear
vim /home/amiralsayed/Downloads/index.html
mkdir lab1
mkdir lab2
s
ls
mv lab1.pdf lab1.sh lec1.sh  lab1/
ls
clear
ls
cd  lab2
ls
clear
vim task1_greeting.sh
chmod +x *
./task1_greeting.sh 
chmod +x *
vim task1_greeting.sh
./task1_greeting.sh 
vim task1_greeting.sh
./task1_greeting.sh 
clear
./task1_greeting.sh 
vim task1_greeting.sh
vim task2_s1.sh
vim task2_s2.sh
chmod +x *
./task2_s1.sh 
vim task2_s1.sh
ls
./task2_s1.sh 
cat task2*
vim task2_s2.sh 
./task2_s1.sh 
vim task2_s1
vim task2_s1.sh 
cat task2*
cleawr
clear
vim task2_s1.sh 
vim task3_mycp.sh
chomod +x *
chmod +x *
./task3_mycp.sh 
ls
touch test1 test2 test3
mkdir d
./task3_mycp.sh  test1 d/
ls d/
./task3_mycp.sh  test2 test3 d/
ls
ls d/
rm d/
rm -rf d/
rm test*
ls
clear
vim task3_mycp.sh
vim task4_mycd.sh
chmod +x *
./task4_mycd.sh 
ls
cd
cd -
ls
cat task4_mycd.sh 
./task4_mycd.sh ..
ls
pwd
clear
source ./*4.sh
source ./task4_mycd.sh 
pwd
. ./task4_mycd.sh 
vim task4_mycd.sh 
./task4_mycd.sh ../
. ./task4_mycd.sh 
clear
cd -
source task4_mycd.sh 
cd -
ls
clear
vim task4_mycd.sh 
vim task5_myls.sh
chmod +x *5*
souce *5*
./task5_myls.sh 
ls
ls -lh
type ls
./task5_myls.sh ../../redHat/
clear
vim task5_myls.sh 
./task5_myls.sh -lah ../../redHat/
vim task5_myls.sh 
./task5_myls.sh -lah ../../redHat/
./task5_myls.sh -l ../../redHat/
./task5_myls.sh -i ../../redHat/
./task5_myls.sh -d ../../redHat/
clear
ls *
cat *
clear
cat *.sh
ls
mv task5_myls.sh task56_myls.sh 
vim task7_mytest.sh
chmod +x task7_mytest.sh 
./task7_mytest.sh 
./task7_mytest.sh task4_mycd.sh 
clear
vim task8_myinfo.sh
chmod +x task8_myinfo.sh 
vim task
vim task8_myinfo.sh
./task8_myinfo.sh 
ls
clear
ls ~
./task8_myinfo.sh 
vim task8_myinfo.sh 
./task8_myinfo.sh 
job
jop
jobs
jops
ls /tmp/amiralsayed_home_copy/
cd /tmp/amiralsayed_home_copy/
ls
clear
cd =
cd -
rm /tmp/amiralsayed_home_copy/
rm -rf /tmp/amiralsayed_home_copy/
rm /tmp/amiralsayed_home_copy/
clear
vim task8_myinfo.sh 
. ./task8_myinfo.sh amiralsayed
job
jobs
bg sleep 499
. ./task8_myinfo.sh amiralsayed
vim task8_myinfo.sh 
. ./task8_myinfo.sh amiralsayed
jobs
kill %1
jobs
ls /tmp/amiralsayed_home_copy/
rm /tmp/amiralsayed_home_copy/
ls
rm -rf /tmp/amiralsayed_home_copy/
ls
clear
a;lsklfjf;llkdsajsda;lkfjsadf;lsdakjfsda;lfjsda;lfjsdf;ldjsaf;lkasdjf;lkdsjaf;lk
lear
clear
colear
clear
cleaw
clear
claewr
[claewr
claewr
[clawer
claew
]clear
clae
clear
ls
cd Desktop/
ls
cd iti_open_source/
ls
cd bash/
ls
mkdir lab3
cd lab
cd lab3/
vim lecture_task1.sh
chmod +x lecture_task1.sh 
./lecture_task1.sh -l
chmod +x lecture_task1.sh 
vim lecture_task1.sh
./lecture_task1.sh -l
cat lecture_task1.sh 
vim lecture_task1.sh
./lecture_task1.sh -l
vim lecture_task1.sh 
./lecture_task1.sh -l
clear
./lecture_task1.sh -R
./lecture_task1.sh -a
./lecture_task1.sh -i
echo botato
echo botato chipso
cat ./lecture_task1.sh 
clear
ls
ls -l
chmod u=x lecture_task1.sh 
./lecture_task1.sh -l
ls -l
chmod u+r lecture_task1.sh 
ls -l
./lecture_task1.sh -l
chmod u-x lecture_task1.sh 
./lecture_task1.sh -l
chmod u+x lecture_task1.sh 
chmod 777 lecture_task1.sh 
ls -lhi lecture_task1.sh 
